
from src.config import FLAGS


import torch
import torch.nn.functional as F
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from torch_geometric.nn import GATConv, GlobalAttention, JumpingKnowledge, TransformerConv, GCNConv
from torch_geometric.nn import global_add_pool
import torch.nn as nn
from scipy.stats import rankdata, kendalltau

from src.nn_att import MyGlobalAttention
from torch.nn import Sequential, Linear, ReLU




class Net(torch.nn.Module):
    def __init__(self, in_channels, edge_dim = 7, init_pragma_dict = None, task = FLAGS.task, num_layers = FLAGS.num_layers, D = FLAGS.D, target = FLAGS.target):
        super(Net, self).__init__()
        self.D = D
        conv_class = TransformerConv
        self.conv_first = conv_class(in_channels, D)
        self.conv_layers = nn.ModuleList()
        for _ in range(num_layers - 1):
            conv = conv_class(D, D)
            self.conv_layers.append(conv)
        # M6，每一conv_layers后加入JKN
        self.jkn = JumpingKnowledge( 'max', channels=D, num_layers=2)
        self.gate_nn = nn.Sequential(nn.Linear(self.D, self.D), ReLU(), Linear(self.D, self.D))
        self.glob = MyGlobalAttention(self.gate_nn, None)

    def forward(self, data):
        x, edge_index, edge_attr, batch= \
            data.x, data.edge_index, data.edge_attr, data.batch
        outs = []
        activation = F.elu
        out = activation(self.conv_first(x, edge_index))

        outs.append(out)

        for i, conv in enumerate(self.conv_layers):
            if FLAGS.encode_edge and  FLAGS.gnn_type == 'transformer':
                out = conv(out, edge_index, edge_attr=edge_attr)
            else:
                out = conv(out, edge_index)
            if i != len(self.conv_layers) - 1:
                out = activation(out)

            outs.append(out)
            out = self.jkn(outs)

        out, _ = self.glob(out, batch)

        return out